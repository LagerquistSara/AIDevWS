using Microsoft.Xrm.Sdk;
using NUnit.Framework;
using System;
using UgWorkshop.Plugins.Tests.Fakes;
using P = UgWorkshop.Plugins.RegistrationRulesPlugin;

namespace UgWorkshop.Plugins.Tests
{
    [TestFixture]
    public class RegistrationRulesPluginTests
    {
        private FakeOrganizationService _service;
        private Entity _event;
        private Entity _otherEvent;
        private Entity _contact;

        [SetUp]
        public void SetUp()
        {
            _service = new FakeOrganizationService();
            _event = _service.Seed(new Entity(P.EventTable) { [P.EventNameColumn] = "Agents 101", [P.CapacityColumn] = 2 });
            _otherEvent = _service.Seed(new Entity(P.EventTable) { [P.EventNameColumn] = "Agents 201", [P.CapacityColumn] = 2 });
            _contact = _service.Seed(new Entity("contact"));
        }

        [Test]
        public void Create_WithFreeSeat_KeepsStatus()
        {
            var target = NewRegistration(_event, _contact);

            Run("Create", target);

            Assert.That(target.Contains(P.StatusColumn), Is.False, "Status is left to the column default (Registered).");
        }

        [Test]
        public void Create_SecondActiveForSameContactAndEvent_IsBlocked()
        {
            SeedRegistration(_event, _contact, P.StatusCheckedIn);

            var ex = Assert.Throws<InvalidPluginExecutionException>(() => Run("Create", NewRegistration(_event, _contact)));

            Assert.That(ex.Message, Is.EqualTo(P.DuplicateMessage));
        }

        [TestCase(P.StatusWaitlisted)]
        [TestCase(P.StatusCancelled)]
        public void Create_WhenEarlierRegistrationDoesNotHoldASeat_IsAllowed(int earlierStatus)
        {
            SeedRegistration(_event, _contact, earlierStatus);

            Assert.DoesNotThrow(() => Run("Create", NewRegistration(_event, _contact)));
        }

        [Test]
        public void Create_SameContactAtAnotherEvent_IsAllowed()
        {
            SeedRegistration(_otherEvent, _contact, P.StatusRegistered);

            Assert.DoesNotThrow(() => Run("Create", NewRegistration(_event, _contact)));
        }

        [Test]
        public void Create_WhenEventIsFull_SetsWaitlisted()
        {
            FillEvent(_event);
            var target = NewRegistration(_event, _contact);

            Run("Create", target);

            Assert.That(target.GetAttributeValue<OptionSetValue>(P.StatusColumn).Value, Is.EqualTo(P.StatusWaitlisted));
        }

        [Test]
        public void Create_WaitlistedAndCancelledRows_DoNotUseSeats()
        {
            SeedRegistration(_event, NewContact(), P.StatusRegistered);
            SeedRegistration(_event, NewContact(), P.StatusWaitlisted);
            SeedRegistration(_event, NewContact(), P.StatusCancelled);
            var target = NewRegistration(_event, _contact);

            Run("Create", target);

            Assert.That(target.Contains(P.StatusColumn), Is.False, "One of two seats is taken, so the new row keeps its seat.");
        }

        [Test]
        public void Create_InactiveRowsDoNotUseSeats()
        {
            var inactive = SeedRegistration(_event, NewContact(), P.StatusRegistered);
            inactive[P.StateCodeColumn] = new OptionSetValue(1);
            _service.Update(inactive);
            SeedRegistration(_event, NewContact(), P.StatusRegistered);
            var target = NewRegistration(_event, _contact);

            Run("Create", target);

            Assert.That(target.Contains(P.StatusColumn), Is.False);
        }

        [Test]
        public void Create_AsWaitlisted_RunsNoQueries()
        {
            FillEvent(_event);
            var target = NewRegistration(_event, _contact);
            target[P.StatusColumn] = new OptionSetValue(P.StatusWaitlisted);

            Run("Create", target);

            Assert.That(_service.Queries, Is.Empty);
            Assert.That(target.GetAttributeValue<OptionSetValue>(P.StatusColumn).Value, Is.EqualTo(P.StatusWaitlisted));
        }

        [Test]
        public void Update_WithoutPreImage_FailsWithClearMessage()
        {
            var row = SeedRegistration(_event, _contact, P.StatusWaitlisted);
            var target = new Entity(P.RegistrationTable, row.Id) { [P.StatusColumn] = new OptionSetValue(P.StatusRegistered) };

            var ex = Assert.Throws<InvalidPluginExecutionException>(() => Run("Update", target, preImage: null));

            Assert.That(ex.Message, Is.EqualTo(P.MissingPreImageMessage));
        }

        [Test]
        public void Update_CheckInOfActiveRegistration_RunsNoQueries()
        {
            FillEvent(_event);
            var row = SeedRegistration(_event, _contact, P.StatusRegistered);
            var target = new Entity(P.RegistrationTable, row.Id) { [P.StatusColumn] = new OptionSetValue(P.StatusCheckedIn) };

            Run("Update", target, PreImageOf(row));

            Assert.That(_service.Queries, Is.Empty, "The row already holds a seat at this event, so nothing is re-checked.");
        }

        [Test]
        public void Update_WaitlistedToRegistered_WithFreeSeat_IsAllowed()
        {
            SeedRegistration(_event, NewContact(), P.StatusRegistered);
            var row = SeedRegistration(_event, _contact, P.StatusWaitlisted);
            var target = new Entity(P.RegistrationTable, row.Id) { [P.StatusColumn] = new OptionSetValue(P.StatusRegistered) };

            Assert.DoesNotThrow(() => Run("Update", target, PreImageOf(row)));
            Assert.That(target.GetAttributeValue<OptionSetValue>(P.StatusColumn).Value, Is.EqualTo(P.StatusRegistered));
        }

        [Test]
        public void Update_WaitlistedToRegistered_WhenFull_IsBlocked()
        {
            FillEvent(_event);
            var row = SeedRegistration(_event, _contact, P.StatusWaitlisted);
            var target = new Entity(P.RegistrationTable, row.Id) { [P.StatusColumn] = new OptionSetValue(P.StatusRegistered) };

            var ex = Assert.Throws<InvalidPluginExecutionException>(() => Run("Update", target, PreImageOf(row)));

            Assert.That(ex.Message, Is.EqualTo(string.Format(P.FullOnUpdateMessage, "Agents 101", 2)));
        }

        [Test]
        public void Update_ChangeContactOnActiveRow_ChecksDuplicateButNotCapacity()
        {
            FillEvent(_event);
            var row = SeedRegistration(_event, NewContact(), P.StatusRegistered);
            var target = new Entity(P.RegistrationTable, row.Id) { [P.ContactColumn] = _contact.ToEntityReference() };

            Assert.DoesNotThrow(() => Run("Update", target, PreImageOf(row)), "The row keeps its own seat at a full event.");

            SeedRegistration(_event, _contact, P.StatusRegistered);
            var ex = Assert.Throws<InvalidPluginExecutionException>(() => Run("Update", target, PreImageOf(row)));
            Assert.That(ex.Message, Is.EqualTo(P.DuplicateMessage));
        }

        [Test]
        public void Update_MoveActiveRowToFullEvent_IsBlocked()
        {
            FillEvent(_otherEvent);
            var row = SeedRegistration(_event, _contact, P.StatusRegistered);
            var target = new Entity(P.RegistrationTable, row.Id) { [P.EventColumn] = _otherEvent.ToEntityReference() };

            var ex = Assert.Throws<InvalidPluginExecutionException>(() => Run("Update", target, PreImageOf(row)));

            Assert.That(ex.Message, Is.EqualTo(string.Format(P.FullOnUpdateMessage, "Agents 201", 2)));
        }

        [Test]
        public void Update_Cancel_RunsNoQueries()
        {
            FillEvent(_event);
            var row = SeedRegistration(_event, _contact, P.StatusRegistered);
            var target = new Entity(P.RegistrationTable, row.Id) { [P.StatusColumn] = new OptionSetValue(P.StatusCancelled) };

            Run("Update", target, PreImageOf(row));

            Assert.That(_service.Queries, Is.Empty);
        }

        [Test]
        public void OtherTable_IsIgnored()
        {
            var pipeline = new FakePluginPipeline(_service, primaryEntityName: "contact");
            pipeline.Context.InputParameters["Target"] = new Entity("contact");

            Assert.DoesNotThrow(() => pipeline.Execute(new P(null, null)));
            Assert.That(_service.Queries, Is.Empty);
        }

        [Test]
        public void PostOperationStage_IsIgnored()
        {
            FillEvent(_event);
            var target = NewRegistration(_event, _contact);

            Run("Create", target, stage: 40);

            Assert.That(target.Contains(P.StatusColumn), Is.False);
            Assert.That(_service.Queries, Is.Empty);
        }

        private void Run(string message, Entity target, Entity preImage = null, int stage = 20)
        {
            var pipeline = new FakePluginPipeline(_service);
            pipeline.Context.MessageName = message;
            pipeline.Context.Stage = stage;
            pipeline.Context.PrimaryEntityId = target.Id;
            pipeline.Context.InputParameters["Target"] = target;
            if (preImage != null)
            {
                pipeline.Context.PreEntityImages[P.PreImageName] = preImage;
            }

            pipeline.Execute(new P(null, null));
        }

        private static Entity NewRegistration(Entity eventRow, Entity contact) =>
            new Entity(P.RegistrationTable)
            {
                [P.EventColumn] = eventRow.ToEntityReference(),
                [P.ContactColumn] = contact.ToEntityReference()
            };

        private Entity SeedRegistration(Entity eventRow, Entity contact, int status)
        {
            var row = NewRegistration(eventRow, contact);
            row[P.StatusColumn] = new OptionSetValue(status);
            return _service.Seed(row);
        }

        private Entity NewContact() => _service.Seed(new Entity("contact"));

        private void FillEvent(Entity eventRow)
        {
            for (var i = 0; i < eventRow.GetAttributeValue<int>(P.CapacityColumn); i++)
            {
                SeedRegistration(eventRow, NewContact(), P.StatusRegistered);
            }
        }

        private static Entity PreImageOf(Entity row) =>
            new Entity(row.LogicalName, row.Id)
            {
                [P.EventColumn] = row[P.EventColumn],
                [P.ContactColumn] = row[P.ContactColumn],
                [P.StatusColumn] = row[P.StatusColumn]
            };
    }
}
