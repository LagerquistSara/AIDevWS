# Lab 4 reference solution — Event Check-in registration rules plug-in

The finished code for Lab 4 of the workshop. Unzip it over your `lab-04-plugin` folder, then build and test from this folder with `dotnet build` and `dotnet test`. Continue with Part C of the lab to register it.

| Folder or file | What it is |
|---|---|
| `UgWorkshop.Plugins.slnx` | Solution with both projects. |
| `src/UgWorkshop.Plugins/` | Signed plug-in project (.NET Framework 4.6.2) built on the `pac plugin init` template. `RegistrationRulesPlugin.cs` contains the rules. |
| `tests/UgWorkshop.Plugins.Tests/` | NUnit tests on .NET 10 (Windows and macOS), using the in-memory fakes in `Fakes/`. No extra packages. |

## Registration

| Setting | Value |
|---|---|
| Plug-in type | `UgWorkshop.Plugins.RegistrationRulesPlugin` |
| Table | `sara_registration` |
| Steps | Create and Update, PreOperation (stage 20), Synchronous |
| Update filtering attributes | `sara_event`, `sara_contact`, `sara_status` |
| Pre-image (Update only) | Name and alias `PreImage`, columns `sara_event`, `sara_contact`, `sara_status` |

## Behaviour

*Active* means Registered or Checked-in; only active, enabled rows (`statecode` 0) use a seat or count as a duplicate. The plug-in counts as SYSTEM, so it sees every registration, not only those the user can read.

| Situation | Result |
|---|---|
| Create, Status empty, Registered or Checked-in, free seat | Saved; Status keeps the column default (Registered) |
| Create when the contact already has an active registration for the event | Error: *This contact already has an active registration (Registered or Checked-in) for this event.* |
| Create when the event is full | Saved as **Waitlisted** |
| Create as Waitlisted or Cancelled | Saved; nothing is checked |
| Update that keeps the row active at the same event and contact (for example Registered → Checked-in) | Saved; nothing is checked |
| Update to Waitlisted or Cancelled | Saved; the seat is freed. Nobody is promoted automatically. |
| Update that takes a new seat (Waitlisted/Cancelled → active, or an active row moved to another event) when the event is full | Error: *The event "…" is full (N seats). Keep this registration Waitlisted, or cancel another registration first.* Rows are only waitlisted automatically on Create. |
| Update that changes the contact or event of an active row to a pair that is already active | Duplicate error |
| Update step without the `PreImage` pre-image | Error that names the missing pre-image |

> **Not concurrency-safe.** The rules count rows one transaction at a time. Two people saving the last seat at the same moment can both get it. See the teaching note in Lab 4.
