using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;

namespace UgWorkshop.Plugins
{
    /// <summary>
    /// Duplicate and capacity rules for Event Check-in registrations.
    /// Registration: sara_registration, PreOperation (20), Synchronous.
    ///   Create: no filtering attributes.
    ///   Update: filtering attributes sara_event, sara_contact, sara_status; pre-image "PreImage" with the same columns.
    /// Teaching code: the count is sequential and is NOT a concurrency-safe seat reservation (see Lab 4).
    /// </summary>
    public class RegistrationRulesPlugin : PluginBase
    {
        public const string PreImageName = "PreImage";

        public const string RegistrationTable = "sara_registration";
        public const string RegistrationId = "sara_registrationid";
        public const string EventColumn = "sara_event";
        public const string ContactColumn = "sara_contact";
        public const string StatusColumn = "sara_status";
        public const string StateCodeColumn = "statecode";

        public const string EventTable = "sara_event";
        public const string EventNameColumn = "sara_name";
        public const string CapacityColumn = "sara_capacity";

        public const int StatusRegistered = 100000000;
        public const int StatusCheckedIn = 100000001;
        public const int StatusWaitlisted = 100000002;
        public const int StatusCancelled = 100000003;

        public const string DuplicateMessage =
            "This contact already has an active registration (Registered or Checked-in) for this event.";
        public const string FullOnUpdateMessage =
            "The event \"{0}\" is full ({1} seats). Keep this registration Waitlisted, or cancel another registration first.";
        public const string MissingPreImageMessage =
            "RegistrationRulesPlugin: the Update step must have a pre-image named PreImage with sara_event, sara_contact and sara_status.";

        private const int StageCreateOrUpdatePreOperation = 20;

        public RegistrationRulesPlugin(string unsecureConfiguration, string secureConfiguration)
            : base(typeof(RegistrationRulesPlugin))
        {
        }

        protected override void ExecuteDataversePlugin(ILocalPluginContext localPluginContext)
        {
            if (localPluginContext == null)
            {
                throw new ArgumentNullException(nameof(localPluginContext));
            }

            var context = localPluginContext.PluginExecutionContext;
            var isCreate = context.MessageName == "Create";
            var isUpdate = context.MessageName == "Update";

            if (context.PrimaryEntityName != RegistrationTable
                || context.Stage != StageCreateOrUpdatePreOperation
                || !(isCreate || isUpdate)
                || !(context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity target))
            {
                localPluginContext.Trace("Not a sara_registration Create/Update in PreOperation; nothing to do.");
                return;
            }

            Entity preImage = null;
            if (isUpdate && !context.PreEntityImages.TryGetValue(PreImageName, out preImage))
            {
                throw new InvalidPluginExecutionException(MissingPreImageMessage);
            }

            // On Update the Target holds only changed columns, so fall back to the pre-image for the rest.
            var eventRef = Current<EntityReference>(target, preImage, EventColumn);
            var contactRef = Current<EntityReference>(target, preImage, ContactColumn);
            // The column default (Registered) is not yet in the Target during PreOperation on Create.
            var status = Current<OptionSetValue>(target, preImage, StatusColumn)?.Value ?? StatusRegistered;

            if (!IsActive(status) || eventRef == null || contactRef == null)
            {
                localPluginContext.Trace($"Status {status} does not use a seat, or Event/Contact is empty; nothing to check.");
                return;
            }

            var wasActive = false;
            var sameEvent = false;
            var sameContact = false;
            if (isUpdate)
            {
                wasActive = IsActive(preImage.GetAttributeValue<OptionSetValue>(StatusColumn)?.Value ?? StatusRegistered);
                sameEvent = preImage.GetAttributeValue<EntityReference>(EventColumn)?.Id == eventRef.Id;
                sameContact = preImage.GetAttributeValue<EntityReference>(ContactColumn)?.Id == contactRef.Id;
            }

            // Already holding a seat at this event for this contact: no new pair and no new seat.
            if (wasActive && sameEvent && sameContact)
            {
                localPluginContext.Trace("Row already active for the same Event and Contact; nothing to check.");
                return;
            }

            // Count as SYSTEM so the rules see every registration, not only the rows the calling user can read.
            var service = localPluginContext.OrgSvcFactory.CreateOrganizationService(null);
            var currentId = isUpdate ? target.Id : Guid.Empty;

            if (HasActiveRegistration(service, eventRef.Id, contactRef.Id, currentId))
            {
                throw new InvalidPluginExecutionException(DuplicateMessage);
            }

            if (wasActive && sameEvent)
            {
                localPluginContext.Trace("Row already holds a seat at this event; capacity unchanged.");
                return;
            }

            var eventRow = service.Retrieve(EventTable, eventRef.Id, new ColumnSet(EventNameColumn, CapacityColumn));
            var capacity = eventRow.GetAttributeValue<int?>(CapacityColumn);
            if (capacity == null)
            {
                localPluginContext.Trace("Event has no capacity; not limiting registrations.");
                return;
            }

            var seatsTaken = CountActiveRegistrations(service, eventRef.Id, currentId, capacity.Value);
            localPluginContext.Trace($"Seats taken by other registrations: {seatsTaken} of {capacity.Value}.");
            if (seatsTaken < capacity.Value)
            {
                return;
            }

            if (isCreate)
            {
                target[StatusColumn] = new OptionSetValue(StatusWaitlisted);
                localPluginContext.Trace("Event is full; new registration set to Waitlisted.");
                return;
            }

            throw new InvalidPluginExecutionException(
                string.Format(FullOnUpdateMessage, eventRow.GetAttributeValue<string>(EventNameColumn), capacity.Value));
        }

        public static bool IsActive(int status) => status == StatusRegistered || status == StatusCheckedIn;

        private static T Current<T>(Entity target, Entity preImage, string column) where T : class
        {
            if (target.Contains(column))
            {
                return target[column] as T;
            }

            return preImage?.GetAttributeValue<T>(column);
        }

        private static bool HasActiveRegistration(IOrganizationService service, Guid eventId, Guid contactId, Guid excludeId)
        {
            var query = ActiveRegistrationsQuery(eventId, excludeId, 1);
            query.Criteria.AddCondition(ContactColumn, ConditionOperator.Equal, contactId);
            return service.RetrieveMultiple(query).Entities.Count > 0;
        }

        private static int CountActiveRegistrations(IOrganizationService service, Guid eventId, Guid excludeId, int capacity)
        {
            // Stop counting at capacity: only "full or not" matters.
            var query = ActiveRegistrationsQuery(eventId, excludeId, Math.Max(capacity, 1));
            return service.RetrieveMultiple(query).Entities.Count;
        }

        private static QueryExpression ActiveRegistrationsQuery(Guid eventId, Guid excludeId, int top)
        {
            var query = new QueryExpression(RegistrationTable)
            {
                ColumnSet = new ColumnSet(RegistrationId),
                TopCount = top
            };
            query.Criteria.AddCondition(EventColumn, ConditionOperator.Equal, eventId);
            query.Criteria.AddCondition(StatusColumn, ConditionOperator.In, StatusRegistered, StatusCheckedIn);
            query.Criteria.AddCondition(StateCodeColumn, ConditionOperator.Equal, 0);
            if (excludeId != Guid.Empty)
            {
                query.Criteria.AddCondition(RegistrationId, ConditionOperator.NotEqual, excludeId);
            }

            return query;
        }
    }
}
